from flask import Flask, render_template, Response, jsonify, request

app = Flask(__name__)

video_camera = None
global_frame = None


@app.route('/')
def index():
    return render_template('index.html')


@app.get('/login')
def login_get():
    return render_template('login.html')


@app.post('/login')
def login_post():
    return 'do_the_login()'


@app.route('/hello/')
@app.route('/hello/<name>')
def hello(name=None):
    return render_template('hello.html', name=name)


@app.route('/capture_client_side')
def capture_client_side():
    return render_template('capture_client_side.html')


@app.errorhandler(404)
def not_found(error):
    return render_template('error.html'), 404


if __name__ == '__main__':
    app.run(host='0.0.0.0', threaded=True)
